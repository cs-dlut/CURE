//package CURE_MemoryM;

public class TFT_ATFT {
	public boolean decision;
	public int[] m_decision = new int[] {1,1}; //memory of self
	public int[] t_decision = new int[] {1,1}; //memory of opponent
	public double score;

	public boolean decision(boolean decision_opp1, boolean decision_opp2)
	{
		m_decision[0]=m_decision[1];
		m_decision[1]=decision_opp1==true?1:0;
		t_decision[0]=t_decision[1];
		t_decision[1]=decision_opp2==true?1:0;

		int mnum = 8*m_decision[0]+4*m_decision[1];//0~15 STATES
		int tnum = 2*t_decision[0]+1*t_decision[1];
		int cj = mnum+tnum;
		if(cj==15 || cj==13 || cj==10 || cj==9 || cj==7 || cj==5 || cj==4 || cj==2 || cj==1)
			//cccc, ccdc, cdcd, cddc, dccc, dcdc, dcdd, ddcd, dddc
		{
			decision = true;
		}
		else
		{
			decision = false;
		}

		return decision;
	}

	public double score(boolean decision1, boolean decision2)
	{

		double R = 3;
		int S = 0;
		int T = 5;
		int P = 1;

		if(decision1) //player1
		{
			if(decision2) //player2
				score = R;
			else
				score = S;
			}
		else
		{	//player1
			if(decision2)
				score = T;
			else
				score = P;
			}

		return score;
	}
}
