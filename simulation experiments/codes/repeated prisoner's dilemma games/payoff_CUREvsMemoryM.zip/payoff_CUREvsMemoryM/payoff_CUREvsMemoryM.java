//package CURE_MemoryM;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

public class payoff_CUREvsMemoryM {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		int round =10000000,times =10000;
		boolean decision_1, decision_2, decision_3, decision_4;
		double score_1, score_2,score_3,score_4;
		double score_FT1,score_FT2;
		int num=0;
		double coop1, coop2, coop3, coop4;
		double Coop1, Coop2;
		BufferedWriter out = null;
		try {
			out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("/result/CURE-TFT-ATFT_R=3.txt", true)));
			out.write("CURE"+" "+"TFT_ATFT_10-noise"+"\r\n");
		} catch (Exception e) {
			e.printStackTrace();
		}

			score_3=0;
			score_4=0;
			coop3=0;
			coop4=0;
			for(int j=0;j<times;j++)
			{

				CURE player1 = new CURE();
				TFT_ATFT player2 = new TFT_ATFT();
				score_1 =0;
				score_2 =0;
				coop1 = 0;
				coop2 = 0;
				player1.decision = true;
				player2.decision = true;
//
//				player1.decision = false;
//				player2.decision = false;

				for(int k=0;k<round;k++)
				{
					decision_3 = player1.decision;
					decision_4 = player2.decision;

					if(Math.random()<0.10)
						decision_3 =!decision_3;
					if(Math.random()<0.10)
						decision_4 =!decision_4;

//					if(k<1000 && j==0)
//					{
//						out.write(player1.decision+" "+player2.decision+"\r\n");
//					}

					coop1 += decision_3==true?1:0;
					coop2 += decision_4==true?1:0;

					score_1 += player1.score(decision_3, decision_4);
					score_2 += player2.score(decision_4, decision_3);

					decision_1 = player1.decision(decision_3, decision_4);
					decision_2 = player2.decision(decision_4,decision_3);

					player1.decision = decision_1;
					player2.decision = decision_2;

				}

				System.out.println(num);
				num++;
				score_1 = score_1/(double)round;
				score_2 = score_2/(double)round;
				score_3 += score_1;//times
				score_4 += score_2;

				coop1 = coop1/(double)round;
				coop2 = coop2/(double)round;
				coop3 += coop1;
				coop4 += coop2;
			}

			score_FT1 = score_3/times;
			score_FT2 = score_4/times;
			Coop1 = coop3/times;
			Coop2 = coop4/times;

			System.out.println(score_FT1+" "+score_FT2);
			out.write(score_FT1+" "+score_FT2+"\r\n");
			out.write(Coop1+" "+Coop2+"\r\n");
				try {
					out.close();
					} catch (IOException e) {
					e.printStackTrace();
					}
	}
}
