//package CURE_MemoryM;

public class AON3 {
	public boolean decision;
	public int[] m_decision = new int[] {1,1,1};// memory of self
	public int[] t_decision = new int[] {1,1,1};// memory of the opponent
	public double score;

	public boolean decision(boolean decision_opp1, boolean decision_opp2)
	{
		m_decision[0]=m_decision[1];
		m_decision[1]=m_decision[2];
		m_decision[2]=decision_opp1==true?1:0;
		t_decision[0]=t_decision[1];
		t_decision[1]=t_decision[2];
		t_decision[2]=decision_opp2==true?1:0;

		int mnum = 32*m_decision[0]+16*m_decision[1]+8*m_decision[2];
		int tnum = 4*t_decision[0]+2*t_decision[1]+1*t_decision[2];
		int cj = mnum+tnum;
		if(cj==0 || cj==9 || cj==18 || cj==27 || cj==36 || cj==45 || cj==54 || cj==63)
			// dddddd, ddcddc, dcddcd, cddcdd, dccdcc, cdccdc, ccdccd, cccccc;
		{
			decision = true;
		}
		else
		{
			decision = false;
		}

		return decision;
	}

	public double score(boolean decision1, boolean decision2)
	{

		double R = 3;
		int S = 0;
		int T = 5;
		int P = 1;

		if(decision1)
		{
			if(decision2)
				score = R;
			else
				score = S;
			}
		else
		{
			if(decision2)
				score = T;
			else
				score = P;
			}

		return score;
	}
}
