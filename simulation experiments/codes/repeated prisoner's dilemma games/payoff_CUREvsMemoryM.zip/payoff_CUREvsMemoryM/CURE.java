//package CURE_MemoryM;

public class CURE {

	public boolean decision;
	public double score;
	int i=0,j=0;
	int t = 1;
	public boolean decision(boolean decision_opp1, boolean decision_opp2)
	{
		if(decision_opp1 && !decision_opp2)
			i+=1;
		if(decision_opp2 && !decision_opp1)
			j+=1;
		if(i -j > t)
		{

			  decision = false;
		}
		else
		{
			  decision = true;
		}
		return decision;
	}

	public double score(boolean decision1, boolean decision2)
	{
		double R = 3;
		int S = 0;
		int T = 5;
		int P = 1;

		if(decision1) //player1 cooperates
		{
			if(decision2) //player2
				score = R;
			else
				score = S;
			}
		else //player1 defects
		{
			if(decision2)
				score = T;
			else
				score = P;
			}

		return score;
	}
}
