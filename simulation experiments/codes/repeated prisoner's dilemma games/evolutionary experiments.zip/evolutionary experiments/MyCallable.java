
import java.util.concurrent.*;

class MyCallable implements Callable<Object>{
	private int start;
	private int end;
	double ave;
	
	MyCallable(int s,int e) {
		this.start = s;
		this.end = e;
	}

	@Override
	public Object call() throws Exception {
		for (int i = start; i < end; ++i)
		{
			DataInter.fitness[i] = 0;
			for (int j = 0; j < DataInter.iii; ++j)
			{
				DataInter.fitness[i] += DataInter.ratio[j] * DataInter.payoff[i][j];
			}
			ave += DataInter.ratio[i] * DataInter.fitness[i];
		}
		return String.valueOf(ave);	
	}
}
