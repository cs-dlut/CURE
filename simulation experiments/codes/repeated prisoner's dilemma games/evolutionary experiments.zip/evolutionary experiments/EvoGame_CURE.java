
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
//��JAVA������Ҫ��һЩ����


public class EvoGame_CURE {	
	
	public static void main(String args[])
	{
    	long begin = System.currentTimeMillis();//��ʱ��
    	EvoGame_CURE onegame = new EvoGame_CURE();
		try{
		onegame.playgame();
		}catch(IOException e)
		{
			e.printStackTrace();
		}
		System.out.println("Game over");
		System.out.println("GAME total time: " + (System.currentTimeMillis() - begin)/1000);//��ӡ������ʱ��
	}

	int iii=DataInter.iii;

	public EvoGame_CURE() 
	{
		Connection c = null;//�ӿ�
	    Statement stmt = null;
	    ResultSet rs=null;
	    try {
	    	
	    	Class.forName("org.sqlite.JDBC");
	    	c = DriverManager.getConnection("jdbc:sqlite:C:/payoff/payoff_CURE01_R=3_delta=1.db3");//.db3�������ݿ��·������IPDstrategy���ļ����ڣ�������ݿ��ļ����ڱ�ĵط�����Ҫ�޸�·��������"jdbc:sqlite:/D/Test/payoff_TFTCT_R=4.db3"����14642�����Ե��������ݿ�Լ12G��С��
	    	c.setAutoCommit(false);
	    	System.out.println("Database connection is normal");//��ӡ�����ݿ�����������

	    	stmt = c.createStatement();
	    	long begin1 = System.currentTimeMillis(); //��ȡ���ݿ⿪ʼ��ʱ
	    	for(int i=0;i<iii;i++)//��˳���ȡ��0,1,2,...,iii������
		    {
		    	for(int j=0;j<iii;j++)//��˳���ȡ���ֲ��ԣ���i�����ԶԿ���j�����ԡ�ÿ��i���ԶԿ�j����ʱ����һ�����档
		    	{
		    		String test = i+","+j;
		    		rs = stmt.executeQuery( "SELECT * FROM payoff where name='"+test+"';" );//�����ݿ��(i,j)��ѡ���Ӧ������ֵ���ܹ���iiixiii������ֵ��
		    		String  value = rs.getString("value");
		    		DataInter.payoff[i][j] = Double.parseDouble(value);//����ȡ��������ֵ�����ڴ���payoff[i][j]���Ը�������ȡʹ�á�
		    	}
		    	System.out.println("reading"+i+"strategy");//��ӡ��������i�����ԡ�
		    }
		    rs.close();
		   	stmt.close();
			
			c.commit();
		    c.close();
		    System.out.println("reading strategy total time: " + (System.currentTimeMillis() - begin1)/1000);//��ӡ����ȡ���Ե�����ʱ��
	    } catch ( Exception e ) {
	      System.err.println( e.getClass().getName() + ": " + e.getMessage() );
	      System.exit(0);
	    }
	}

	
	@SuppressWarnings("unchecked")

	void playgame() throws IOException
	{
		String ratio_out="ratio";
		String payoff_out="payoff";
		
		String ratio_out_colName="ratioEvery";
		String colName_generation="generation";
		String payoff_out_colName="avePayoff";

		
		int generation = 1000000;
		int g=0;
		List<String> list_ratio1 = new ArrayList<String>();
		for(int i=0;i<iii;i++)
		{
			list_ratio1.add("stra."+String.valueOf(i+1));//��ͷ��stra1,stra2,...
		}
		appendData(ratio_out, colName_generation,ratio_out_colName,"name",list_ratio1);
		list_ratio1.clear();
		for(int i=0;i<iii;i++)
		{
			
			DataInter.ratio[i] =(1.0/Double.valueOf(iii));
			list_ratio1.add(""+DataInter.ratio[i]);

		}
		appendData(ratio_out, colName_generation,ratio_out_colName,"init",list_ratio1);
		list_ratio1.clear();
		list_ratio1.add("ave_total_payoff");
		appendData(payoff_out, colName_generation,payoff_out_colName,"name",list_ratio1);
		list_ratio1.clear();
//evolution
		while(g<=generation)
		{
			long begin = System.currentTimeMillis();
			
			double ave_fitness=0;
			if(g%100==0)
			{
		    	System.out.println("g= "+g);
			}
			List<String> list_ratio = new ArrayList<String>();
			List<String> list_payoff = new ArrayList<String>();

			int taskSize = 8;//multi-threaded operation:8,16 or 20
			ExecutorService pool = Executors.newFixedThreadPool(taskSize);
			@SuppressWarnings("rawtypes")
			List<Future> list = new ArrayList<Future>();
			for (int i = 0; i < taskSize; i++) {
				if(taskSize-1 == i)
				{
					Callable<Object> c = new MyCallable(iii/taskSize*i ,iii);
					Future<Object> f = pool.submit(c);
					list.add(f);
				}
				else
				{
					Callable<Object> c = new MyCallable(iii/taskSize*i ,iii/taskSize*(i+1));
					Future<Object> f = pool.submit(c);
					list.add(f);
				}			
			}
			pool.shutdown();

			for (Future<Object> f : list) {
				try {
					Object re = f.get();
					ave_fitness = ave_fitness +  Double.parseDouble(re.toString()) ;
				} catch (InterruptedException | ExecutionException e) {
					e.printStackTrace();
				}
				
			}
			
			for(int i=0;i<iii;i++)
			{
				DataInter.ratio[i] = DataInter.ratio[i]*DataInter.fitness[i]/ave_fitness;
				
				if(g<1000||g%50 == 0)
					list_ratio.add(""+DataInter.ratio[i]);
//		
			}
			if(g<1000||g%50 == 0)
			{
				list_payoff.add(""+ave_fitness);
//		
				appendData(ratio_out,colName_generation, ratio_out_colName,String.valueOf(g),list_ratio);
				appendData(payoff_out,colName_generation, payoff_out_colName,String.valueOf(g),list_payoff);
			}
			if(g>2000 && Math.random()<0.1)
				
				mutation(g);
			g++;
			
		}
	}
//mutation function
	public void mutation(int mut_g) throws IOException
	{
		int num_mut = (int)(Math.random()*(iii-1));
		float sum_mut=0;
		for(int i=0;i<iii-1;i++)
			{
			DataInter.ratio[i] = (double) (DataInter.ratio[i]*0.999);
			sum_mut += DataInter.ratio[i];
			}
		DataInter.ratio[num_mut] =(double) (DataInter.ratio[num_mut]+0.001);
		
	}
//output
	  public boolean appendData(String tableName, String colName,String colName2,String gen,List<String> data){
	        try {

	        	Class.forName("org.sqlite.JDBC");
				Connection c = DriverManager.getConnection("jdbc:sqlite:C:/Results/result_CURE_01_CUREnoMUTATION.db");
				c.setAutoCommit(false);

				Statement stmt = c.createStatement();

	            StringBuffer sb = new StringBuffer();
	            for(int j=0; j<data.size(); j++)
	            {
	            	if(j<data.size()-1)
	            		sb.append(data.get(j)+",");
	            	else
	            		sb.append(data.get(j)+"");
	            }
	           
				String sql = "INSERT INTO "+ tableName+" ("+colName+","+colName2+")" + "VALUES ("+"\""+gen+"\""+","+"\""+sb.toString()+"\""+");";

				stmt.executeUpdate(sql);

				stmt.close();
				
				c.commit();
				c.close();
	            return true;
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        return false;
	    }

}
