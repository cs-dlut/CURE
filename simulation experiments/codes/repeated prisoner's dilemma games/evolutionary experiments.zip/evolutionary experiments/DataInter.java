public class DataInter {
	public static int iii=14642;
	public static double[][] payoff = new double[iii][iii];
	public static double[] ratio = new double[iii];
	public static double[] fitness = new double[iii];
}
