//package payoff;

public class DiscCURE {
	public boolean decision;
	public double score;
	int t = 1;
	double dk = 0;
	double unfair;
	double disc = 0.99;
	public boolean decision(boolean decision_opp1, boolean decision_opp2)
	{

		if(decision_opp1 && !decision_opp2)
			unfair = 1;
		else if(decision_opp2 && !decision_opp1)
			unfair = -1;
		else
			unfair = 0;

		dk = disc*dk + unfair;

		if(dk > t)
		{

			  decision = false;
		}
		else
		{
			  decision = true;
		}

		return decision;
	}

	public double score(boolean decision1, boolean decision2)
	{

		double R = 3;
		int S = 0;
		int T = 5;
		int P = 1;

		if(decision1)
		{
			if(decision2)
				score = R;
			else
				score = S;
			}
		else
		{
			if(decision2)
				score = T;
			else
				score = P;
			}

		return score;
	}
}
