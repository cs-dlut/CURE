# cure
Repeated PD with errors implemented in oTree

oTree documentations have all up to date instructions on how to install oTree and run games.
https://otree.readthedocs.io/en/latest/

This version was built and ran with oTree 5.

There are two conditions, one is a normal 20+ round prisoner's dilemma and the other the same game but with 10% errors in implementing player's decisions. 
